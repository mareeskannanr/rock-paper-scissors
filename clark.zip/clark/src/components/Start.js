import React from 'react';

import data from '../questionnaire.json';

export default props => (
    <div className='card text-center' style={{padding: '20px'}}>
        <h2>{data.questionnaire.name}</h2>
        <h4>{data.questionnaire.description}</h4>
        <button type='button' className='btn btn-success' onClick={() => props.getStart()}>
            <b><span className='fas fa-clipboard'></span> Start</b>
        </button>
    </div>
);