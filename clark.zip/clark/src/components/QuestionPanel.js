import React, { Component } from 'react';

import data from '../questionnaire.json';

export default class QuestionPanel extends Component {

    questions = [];
    parentQuestions = [];
    jumpQuestions = [];
    jumpMap = new Map();
    answers = [];

    state = {
        question: {},
        answer: ''
    };

    constructor(props) {
        super(props);

        let questions = data.questionnaire.questions;
        this.questions = [...questions];
     
        questions.forEach(question => {
            question.jumps.forEach(jump => this.jumpMap.set(jump.destination.id, question.identifier));

            if(this.jumpMap.has(question.identifier)) {
                this.jumpQuestions.push(question);
            } else {
                this.parentQuestions.push(question);
            }
        });

        //console.log(this.questions, this.parentQuestions, this.jumpQuestions, this.jumpSet, this.answers);
    }

    componentDidMount() {
        this.setState({
            question: {...this.parentQuestions[0], index: 0}
        })
    }

    setStateObject(state) {
        return setTimeout(() => {
            this.setState({...state});
            this.props.showLoader(false);
        }, 3000);
    }

    previousQuestion() {
        this.props.showLoader(true);

        this.saveAnswer();

        for(let i=0,length=this.answers.length; i<length; i++) {
            if(this.answers[i].question.identifier === this.state.question.identifier && i > 0) {
                return this.setStateObject(this.answers[i - 1]);
            }
        }

        if(this.state.question.index)  {
            let index = this.state.question.index - 1;
            return this.setStateObject(this.answers[index]);
            
        }
    }

    saveAnswer() {
        let itemFound = false;
        for(let i=0, length=this.answers.length; i<length; i++) {
            if(this.answers[i].question.identifier === this.state.question.identifier) {
                this.answers[i] = {...this.state};
                itemFound = true;
                break;
            }
        }

        if(!itemFound) {

            if(this.jumpMap.get(this.state.question.identifier)) {
                let index = -1;
                for(let i=0,length=this.answers.length; i<length; i++) {
                    if(this.answers[i].question.identifier === this.state.question.identifier) {
                        index = i;
                        break;
                    }
                }

                if(index > -1) {
                    return this.answers[index] = {...this.state};
                }
            }

            this.answers.push({...this.state});
        }

    }

    nextQuestion() {
        this.props.showLoader(true);
        this.saveAnswer();

        let question = null, index = null, answer = '';
        if(this.state.question.jumps.length > 0) {
            let itemFound = false;
            index = this.state.question.index;
            for(let item of this.state.question.jumps) {
                for(let condition of item.conditions) {
                    console.log(this.state.answer);
                    console.log('_______________');
                    let tempAnswer = "Nein";
                    if(this.state.answer["Ja"]) {
                        tempAnswer = "Ja";
                    }

                    if(condition.value === tempAnswer) {
                        question = this.questions.filter(quest => quest.identifier === item.destination.id)[0];
                        itemFound = true;
                        break;
                    }
                }
                if(itemFound) {
                    break;
                }
            }
        } else {
            index = this.state.question.index + 1;
            question = this.parentQuestions[index];
            answer = {};
            if(question && question.choices && question.choices.length > 0) {
                question.choices.forEach(item => answer[item.value] = false);
            }
        }

        if(question) {
            let result = this.answers.filter(answer => answer.question.identifier === question.identifier);
            
            return this.setStateObject({
                question: {...question, index},
                answer: result.length === 0 ? answer: result[0].answer
            });
        }

    }

    textOnChange(e) {
        this.setState({
            answer: e.target.value
        });

        this.saveAnswer();
    }

    checkboxChange(value, e) {
        let answer = {...this.state.answer};
        answer[value] = e.target.checked;

        this.setState({
            answer
        });

        console.log(this.state.answer);

        this.saveAnswer();
    }

    render() {
        return (
            <div className='row'>
                <div className="card col-12">
                    <div className="card-body">
                        <div className='row'>
                            <div className='col-1.5'>
                                {
                                    <button type='button' className='btn btn-primary d-none d-sm-block' onClick={() => this.previousQuestion()}>
                                        <span className='fas fa-arrow-left'></span><span className='d-none d-sm-block'>Previous</span>
                                    </button>
                                }
                            </div>
                            <div className='col-9'>
                                <h5 className="card-title text-center" style={{'marginTop': '10px'}}>
                                    {this.state.question.headline}
                                </h5>
                            </div>
                            <div className='col-1.5'>
                                <button type='button' className='float-right btn btn-primary d-none d-sm-block' onClick={() => this.nextQuestion()}>
                                    <span className='fas fa-arrow-right'></span><span className='d-none d-sm-block'>Next</span>
                                </button>
                            </div>
                        </div>
                        <hr />
                        <div className='col-12 d-block d-sm-none'>
                            <button type='button' className='float-left btn btn-xs btn-primary' onClick={() => this.gotoPrevious()}>
                                <span className='fas fa-arrow-left'></span>
                            </button>
                            <button type='button' className='float-right btn btn-xs btn-primary' onClick={() => this.gotoNext()}>
                                <span className='fas fa-arrow-right'></span>
                            </button>
                        </div>
                        <div className='col-12'>
                            <h4 className="card-subtitle mb-2 text-muted">{this.state.question.description}</h4>
                            {/**<h4>{JSON.stringify(this.state.question)}</h4>**/}
                            {
                                (this.state.question.choices && this.state.question.choices.length === 2) &&
                                <div>
                                    {
                                        this.state.question.choices.map(item => (
                                            <div key={item.value} className='form-check' style={{padding: '25px'}}>
                                                <label className="form-check-label"><input type="radio" className='form-check-input' name={this.state.question.identifier}  checked={this.state.answer[item.value]} value={this.state.answer[item.value]} onChange={e => this.checkboxChange(item.value, e)}  /> {item.label}</label>
                                            </div>
                                        ))
                                    }
                                </div>
                            }

                            {
                                (this.state.question.choices && this.state.question.choices.length > 2) &&
                                <div>
                                    {
                                        this.state.question.choices.map(item => (
                                            <div key={item.value} className='form-check' style={{padding: '25px'}}>
                                                <label className="form-check-label"><input type="checkbox" className='form-check-input' name={this.state.question.identifier} checked={this.state.answer[item.value]} value={this.state.answer[item.value]} onChange={e => this.checkboxChange(item.value, e)} /> {item.label}</label>
                                            </div>
                                        ))
                                    }
                                </div>
                            }
                            {
                                (this.state.question.question_type === 'text' && this.state.question.identifier.includes('date')) &&
                                <div className="form-group" style={{marginTop: '100px'}}>
                                    <input type="date" className="form-control" value={this.state.answer} name={this.state.question.identifier}  onChange={e => this.textOnChange(e)} />
                                </div>
                            }
                            {
                                (this.state.question.question_type === 'text' && this.state.question.identifier.includes('textarea')) &&
                                <div className="form-group" style={{marginTop: '100px'}}>
                                    <textarea className="form-control" value={this.state.answer} name={this.state.question.identifier} rows="5" onChange={e => this.textOnChange(e)}></textarea>
                                </div>
                            }
                        </div>
                    </div>
                </div>
            </div>
        );
    }

}