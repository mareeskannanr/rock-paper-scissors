import React, { Component } from 'react';

import LoadingOverlay from 'react-loading-overlay';
import { RingLoader } from 'react-spinners';

import Start from './Start';
import QuestionPanel from './QuestionPanel';

export default class App extends Component {

    state = {
        canStart: false,
        loader: false
    };

    showLoader(loader) {
        this.setState({
            loader
        });
    }

    render() {
        return (
            <div className='row'>
                <LoadingOverlay active={this.state.loader} spinner={<RingLoader />} styles={{
                    overlay: (base) => ({
                    ...base,
                    backgroundColor: 'rgba(236, 232, 232, 0.7)'
                    })
                }}>
                    <div className='col-12 body'>
                        {!this.state.canStart && <Start getStart={() => this.setState({ canStart: true })} />}
                        {this.state.canStart && <QuestionPanel showLoader={loader => this.showLoader(loader)} />}
                    </div>
                </LoadingOverlay>
            </div>
        );
    };

};