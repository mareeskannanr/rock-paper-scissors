import { createStore, applyMiddleware } from "redux";
import books from '../reducers/answers';
import thunk from 'redux-thunk';
 
export default () => createStore(books, applyMiddleware(thunk));