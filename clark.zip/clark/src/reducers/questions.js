import data from '../questionnaire.json';

const initialState = {
    questionnaire: {...data.questionnaire}
};

export default (state = initialState, action) => {
    switch(action.type) {
        case 'GET_QUESTION': {
            let { id } = { ...action.payload };
            return state.answers.get(id);
        }
    }

    return state;
    
};