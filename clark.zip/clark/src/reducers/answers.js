const initialState = {
    answers: new Map()
};

export default (state = initialState, action) => {
    switch(action.type) {
        case 'SAVE_ANSWER': {
            let { id, answer } = { ...action.payload };
            return state.answers.set(id, answer);
        }

        case 'GET_ANSWER': {
            let { id } = { ...action.payload };
            return state.answers.get(id);
        }
    }

    return state;
};