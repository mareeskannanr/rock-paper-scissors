const _addAnswer = answer => ({
    type: 'SAVE_ANSWER',
    answer
});

const _getAnswer = questionId => ({
    type: 'GET_ANSWER',
    questionId
});

export const addAnswer = (answer = {
    id: '',
    answer: ''
}) => {
    return dispatch => dispatch(_addAnswer(answer));
};

export const getAnswer = (answer = {
    id: ''
}) => {
    return dispatch => dispatch(_getAnswer(answer));
};