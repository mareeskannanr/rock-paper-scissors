const router = require('express').Router;
const controller = require('../controllers/case');

router.route('/')
    .post(controller.saveTask)
    .get(controller.getAllTasks);

module.exports = router;