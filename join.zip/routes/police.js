const router = require('express').Router;
const controller = require('../controllers/police');

router.route('/')
    .post(controller.savePolice);
    //.put(controller.mPolice);

module.exports = router;