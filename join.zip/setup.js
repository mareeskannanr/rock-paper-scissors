const { Client } = require('pg');
const logger = require('morgan');

const config = require('./config');

module.exports = {
    async doInitialSetup() {
        try {
            let dbConnection = await this.getDBConnection();
            
            //Will return a test db connection to consume for testing
            if(process.env.NODE_ENV === 'test') {
                await this.prepareTestDB(dbConnection);
            }

            await this.prepareTables(dbConnection);

            return dbConnection;
        } catch(e) {
            logger.error(e);
            throw e;
        }
    },

    async readSchemas() {
        try {
            let police = await readFile('./models/police.sql');
            let stolenCase = await readFile('./models/stolen_cases.sql');

            police = police.toString();
            stolenCase = stolenCase.toString();

            return { police, stolenCase };
        } catch(e) {
            logger.error(e);
            throw new Error('Schema File Read Error');
        }
    },

    async getDBConnection(envType) {
        let connectionString = "";
        if(process.env.DATABASE_URL != "") {
            connectionString = process.env.DATABASE_URL;
        } else {
            connectionString = config.DB_CONNECTION_STRING + (envType === 'test' ? config.TEST_DB : config.DEV_DB);
        }

        let client = new Client({
            connectionString
        });

        let promise = new Promise((resolve, reject) => {
            client.connect((err, connection) => {
                if(err) {
                    reject(new Error(err));
                }
    
                resolve(connection);
            });
        });

        return await promise.then(connection => { return connection; })
                            .catch(e => {
                                logger.error(e);
                                throw new Error('Error occured while connecting to Task DB');
                            });
    },

    async prepareTables(dbConnection) {
        try {
            let schemas = this.readSchemas();
            await dbConnection.query(schemas.police);
            await dbConnection.query(schemas.stolenCase);
            logger.info('Initial Setup Completed Successfully!');
        } catch(e) {
            logger.error(e);
            throw new Error('Exception While Creating Users Table');
        } 
    },

    async prepareTestDB(dbConnection) {
        try {
            let queryString = `DROP DATABASE IF EXISTS $1;`;
            await dbConnection.query(queryString, [`${config.TEST_DB}`]);

            queryString = `CREATE DATABASE $1;`;
            await dbConnection.query(queryString, [`${config.TEST_DB}`]);

            dbConnection = await this.getDBConnection('test');

        } catch(e) {
            logger.error(e);
            throw new Error('Exception While Preparing Test DB');
        }
    }
};