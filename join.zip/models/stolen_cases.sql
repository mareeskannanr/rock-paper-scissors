CREATE TABLE IF NOT EXISTS stolen_cases (
    id SERIAL PRIMARY KEY,
    created_on TIMESTAMP WITH TIME ZONE,
    last_modified_on TIMESTAMP WITH TIME ZONE,
    file_no TEXT UNIQUE,
    licence_no TEXT NOT NULL,
    color TEXT NOT NULL,
    type TEXT NOT NULL,
    owner_name TEXT NOT NULL,
    theft_description TEXT NOT NULL,
    is_resolved BOOLEAN,
    resolved_on TEXT,
    resolution_comments TEXT,
    assigned_to INT REFERENCES police(id)
);