CREATE TABLE IF NOT EXISTS police (
    id SERIAL PRIMARY KEY,
    created_on TIMESTAMP WITH TIME ZONE DEFAULT now(),
    last_modified_on TIMESTAMP WITH TIME ZONE DEFAULT now(),
    police_no TEXT UNIQUE,
    name TEXT NOT NULL,
    last_case_assigned_on TIMESTAMP WITH TIME ZONE,
    last_case_resolved_on TIMESTAMP WITH TIME ZONE,
    is_free BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE
);