const logger = require('morgan');

module.exports = {

    async savePolice(req, res) {
        try {
            if(!req.body.name && !req.body.name.trim()) {
                return res.status(400).body({
                    message: 'name is required'
                });
            }
    
            dbConnection.query('BEGIN;');

            let result = dbConnection.query('INSERT INTO police(name) VALUES ($1) RETURNING id;', [req.body.name]);
            let id = "" + result.rows[0].id;
            id = id.padStart(4, '0');
            let policeNo = "POL" + id;

            result = dbConnection.query('UPDATE police SET police_no=$1 WHERE id=$2 RETURNING *;', [policeNo, id]);
            dbConnection.query('COMMIT;');
            return res.status(400).body({
                ...result.rows[0]
            });

        } catch(e) {
            logger.error(e);
            dbConnection.query('ROLLBACK;');
        }
    }

};