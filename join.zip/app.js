const express = require('express');
const logger = require('morgan');
const cors = require('cors');

const config = require('./config');
const setup = require('./setup');

const policeRoutes = require('./routes/police');
const caseRoutes = require('./routes/case');

const PORT = process.env.PORT || config.PORT;

const app = express();

app.use(express.json());
app.use(cors());
app.use(express.urlencoded({
    extended: true
}));

app.use('/api/police', policeRoutes);
app.use('/api/case', caseRoutes);

// route for handling 404 requests(unavailable routes)
app.use((req, res) => res.status(404).send("Sorry can't find that!"));

setup.doInitialSetup().then(connection => {
    
    //Only one connection established for the entire application, can be access from anywhere in the application
    global.dbConnection = connection;

    app.listen(PORT, () => {
        logger.info(`Stolen Bike Cases Application is running on port ${PORT}`);
        
        //To Indicate Test Cases to begin after DB connection established
        app.emit("app_started");
    });
}).catch(error => {
    //logger.error(error);
    logger.error('Due to Data Connection Problem, Server not get started!');
});

//For Testing
module.exports = app;